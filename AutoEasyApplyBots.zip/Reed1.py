import undetected_chromedriver as uc
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains

def read_job_filters(file_path="job_filters.txt"):
    """Reads job filters from a text file."""
    filters = {}
    try:
        with open(file_path, "r") as file:
            for line in file:
                if "=" in line and not line.strip().startswith("#"):
                    key, value = line.strip().split("=", 1)
                    filters[key.strip()] = value.strip()
    except FileNotFoundError:
        print(f"Error: {file_path} not found. Please create the file with job filters.")
        exit()
    return filters

def highlight_element(driver, element):
    """Highlight an element before clicking it."""
    try:
        actions = ActionChains(driver)
        actions.move_to_element(element)
        actions.perform()
        time.sleep(0.5)
        driver.execute_script("arguments[0].style.backgroundColor = 'yellow'", element)
        time.sleep(0.5)
        driver.execute_script("arguments[0].style.backgroundColor = ''", element)
    except:
        pass

def close_popups(driver):
    """Close any pop-ups that might appear."""
    try:
        # Try to close cookie banner if present
        try:
            cookie_buttons = driver.find_elements(By.XPATH, "//button[contains(text(), 'Accept') or contains(text(), 'accept')]")
            for button in cookie_buttons:
                if button.is_displayed():
                    button.click()
                    time.sleep(1)
                    break
        except:
            pass
        
        # Try to close any other popups
        popup_selectors = [
            "//button[@aria-label='Close']",
            "//button[contains(@class, 'close')]",
            "//div[contains(@class, 'popup')]//button",
            "//div[contains(@class, 'modal')]//button",
            "//button[contains(@class, 'modal-close')]",
            "//div[contains(@class, 'overlay')]//button"
        ]
        
        for selector in popup_selectors:
            try:
                popup_buttons = driver.find_elements(By.XPATH, selector)
                for button in popup_buttons:
                    if button.is_displayed():
                        button.click()
                        time.sleep(1)
            except:
                continue
    except Exception as e:
        print(f"Error closing popups: {e}")

def search_jobs(driver, filters):
    """Search for jobs using the provided filters on Reed.co.uk."""
    try:
        wait = WebDriverWait(driver, 20)  # Increased wait time
        
        # Go to search page first
        driver.get("https://www.reed.co.uk/")
        time.sleep(5)  # Increased wait time for initial page load
        
        # Accept cookies if present
        close_popups(driver)
        
        # Fill in job title
        try:
            what_field = wait.until(EC.presence_of_element_located((By.ID, "keywords")))
            what_field.clear()
            what_field.send_keys(filters['job_title'])
            print(f"Entered job title: {filters['job_title']}")
        except Exception as e:
            print(f"Error entering job title: {e}")
        
        # Fill in location
        try:
            where_field = driver.find_element(By.ID, "location")
            where_field.clear()
            where_field.send_keys(filters['location'])
            print(f"Entered location: {filters['location']}")
        except Exception as e:
            print(f"Error entering location: {e}")
        
        # Check the "Easy Apply" checkbox
        try:
            easy_apply_checkbox = driver.find_element(By.ID, "isEasyApply")
            if not easy_apply_checkbox.is_selected():
                easy_apply_checkbox.click()
                print("Selected 'Easy Apply' filter")
        except Exception as e:
            print(f"Error selecting Easy Apply filter: {e}")
        
        # Click Search button
        try:
            search_button = wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//button[@data-qa='searchJobsBtn']")
            ))
            highlight_element(driver, search_button)
            search_button.click()
            print("Clicked search button")
            time.sleep(5)  # Wait for results to load
        except Exception as e:
            print(f"Error clicking search button: {e}")
            # Try to submit the form directly
            try:
                what_field.submit()
                print("Submitted form directly")
                time.sleep(5)
            except Exception as e2:
                print(f"Error submitting form: {e2}")

    except Exception as e:
        print(f"Error during job search: {e}")

def apply_to_job(driver, job_element):
    """Apply to a job on Reed.co.uk."""
    try:
        # Get job title for reporting
        try:
            job_title_elem = job_element.find_element(By.CSS_SELECTOR, "h2")
            job_title = job_title_elem.text.strip()
            print(f"Attempting to apply for: {job_title}")
        except Exception as e:
            job_title = "Unknown Job"
            print(f"Could not get job title: {e}")
        
        # Find and click Easy Apply button
        try:
            apply_button = job_element.find_element(By.XPATH, ".//button[@data-qa='applyJobBtn']")
            highlight_element(driver, apply_button)
            apply_button.click()
            time.sleep(3)  # Wait for application modal to open
            print(f"Clicked 'Easy Apply' for: {job_title}")
            
            # Submit application
            try:
                submit_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable(
                    (By.XPATH, "//button[@data-qa='submit-application-btn']")
                ))
                highlight_element(driver, submit_button)
                submit_button.click()
                time.sleep(3)  # Wait for confirmation
                print(f"Submitted application for: {job_title}")
                
                # Click OK on confirmation dialog
                try:
                    ok_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable(
                        (By.XPATH, "//button[contains(@class, 'application-confirmation-modal') or text()='OK']")
                    ))
                    highlight_element(driver, ok_button)
                    ok_button.click()
                    time.sleep(2)
                    print(f"Successfully applied to: {job_title}")
                    return True
                except Exception as e:
                    print(f"Error clicking OK button: {e}")
                    # Try to close the dialog or modal if OK button not found
                    try:
                        close_buttons = driver.find_elements(By.XPATH, "//button[@aria-label='Close']")
                        for button in close_buttons:
                            if button.is_displayed():
                                button.click()
                                time.sleep(1)
                                break
                    except:
                        pass
                    return False
            except Exception as e:
                print(f"Error submitting application: {e}")
                return False
        except Exception as e:
            print(f"Error finding apply button: {e}")
            return False
    except Exception as e:
        print(f"Error applying to job: {e}")
        return False

def handle_session_errors(driver, url):
    """Handle session errors by refreshing or navigating."""
    try:
        # Check if there are session errors in the page source
        if "Invalid Session ID" in driver.page_source or "Session expired" in driver.page_source:
            print("Session error detected, attempting to recover...")
            # Try refreshing the page first
            driver.refresh()
            time.sleep(5)
            
            # If still having issues, try navigating to the URL again
            if "Invalid Session ID" in driver.page_source or "Session expired" in driver.page_source:
                print("Still experiencing session issues, trying to navigate again...")
                driver.get(url)
                time.sleep(5)
                
            return True  # Session error was detected and handled
        return False  # No session error detected
    except Exception as e:
        print(f"Error handling session errors: {e}")
        return False

def main():
    """Launch an undetected Chrome session and automate job applications on Reed.co.uk."""
    try:
        filters = read_job_filters()
        
        options = uc.ChromeOptions()
        options.add_argument("--start-maximized")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-notifications")
        options.add_argument("--disable-popup-blocking")
        
        # Increase stability
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        
        print("Starting Chrome browser...")
        driver = uc.Chrome(options=options, version_main=136)
        wait = WebDriverWait(driver, 15)  # Increased wait time
        
        # Check if login is needed
        need_login = input("Do you need to login first? (y/n): ").lower().strip()
        if need_login == 'y':
            try:
                driver.get("https://www.reed.co.uk/account/signin")
                time.sleep(3)
                
                # Accept cookies if present
                close_popups(driver)
                
                print("Please log in manually...")
                input("After logging in, press Enter to continue...")
                print("Login complete. Proceeding with job search...")
            except Exception as e:
                print(f"Error during login: {e}")
        
        # Perform the search
        search_jobs(driver, filters)
        
        jobs_applied = 0
        jobs_skipped = 0
        page_num = 1
        
        # Define a function to check and handle session errors
        def check_session_errors():
            if "Invalid Session ID" in driver.page_source or "Session expired" in driver.page_source:
                print("Session error detected, attempting to recover...")
                driver.refresh()
                time.sleep(5)
                return True
            return False
        
        while True:
            try:
                print(f"\n--- Processing page {page_num} ---")
                time.sleep(5)  # Increased wait time for page to fully load
                
                # Take a screenshot for debugging
                try:
                    driver.save_screenshot(f"reed_page_{page_num}.png")
                    print(f"Screenshot saved as reed_page_{page_num}.png")
                except:
                    pass
                
                # Check for session errors
                check_session_errors()
                
                # Find all job listings with Easy Apply button
                job_cards = []
                try:
                    # Look for job cards
                    job_cards = driver.find_elements(By.XPATH, "//article[contains(@class, 'job-card')]")
                    print(f"Found {len(job_cards)} job cards")
                except Exception as e:
                    print(f"Error finding job cards: {e}")
                
                # If no job listings found
                if len(job_cards) == 0:
                    print("No job cards found on this page.")
                    break
                
                # Process each job listing
                for i, job_card in enumerate(job_cards):
                    try:
                        print(f"\nProcessing job: {i+1} of {len(job_cards)}")
                        
                        # Check if this job has an Easy Apply button
                        easy_apply_button = None
                        try:
                            easy_apply_button = job_card.find_element(By.XPATH, ".//button[@data-qa='applyJobBtn']")
                        except:
                            pass
                        
                        if not easy_apply_button:
                            print("Skipping job - not an Easy Apply job")
                            jobs_skipped += 1
                            continue
                        
                        # Apply to the job
                        success = apply_to_job(driver, job_card)
                        if success:
                            jobs_applied += 1
                        else:
                            jobs_skipped += 1
                            
                    except Exception as e:
                        print(f"Error processing job: {e}")
                        jobs_skipped += 1
                        continue
                
                # Try to go to next page
                try:
                    # Look for next page link
                    next_page = None
                    try:
                        next_page = driver.find_element(By.XPATH, "//a[contains(@class, 'page-link next')]")
                    except:
                        print("No next page button found")
                        break
                    
                    if next_page:
                        highlight_element(driver, next_page)
                        next_page.click()
                        page_num += 1
                        print(f"Going to page {page_num}")
                        time.sleep(7)  # Increased wait time for page load
                        
                        # Check for session errors and try to recover
                        check_session_errors()
                    else:
                        print("No more pages available")
                        break
                        
                except Exception as e:
                    print(f"Error navigating to next page: {e}")
                    
                    # Try direct URL navigation as fallback
                    try:
                        job_title_url = filters['job_title'].replace(' ', '-').lower()
                        next_page_url = f"https://www.reed.co.uk/jobs/{job_title_url}-jobs-in-{filters['location'].replace(' ', '-').lower()}?pageno={page_num+1}&isEasyApply=true"
                        print(f"Attempting to navigate directly to: {next_page_url}")
                        driver.get(next_page_url)
                        page_num += 1
                        time.sleep(7)
                    except Exception as e2:
                        print(f"Error with direct navigation: {e2}")
                        break
                    
            except Exception as e:
                print(f"Error processing page: {e}")
                break
        
        print(f"\nApplication process completed:")
        print(f"- Applied to {jobs_applied} jobs")
        print(f"- Skipped {jobs_skipped} jobs")
        input("Press Enter to close the browser...")
        
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    main()
