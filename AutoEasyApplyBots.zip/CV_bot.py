import undetected_chromedriver as uc
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains

def read_job_filters(file_path="job_filters.txt"):
    """Reads job filters from a text file."""
    filters = {}
    try:
        with open(file_path, "r") as file:
            for line in file:
                if "=" in line and not line.strip().startswith("#"):
                    key, value = line.strip().split("=", 1)
                    filters[key.strip()] = value.strip()
    except FileNotFoundError:
        print(f"Error: {file_path} not found. Please create the file with job filters.")
        exit()
    return filters

def search_jobs(driver, filters):
    """Search for jobs using the provided filters."""
    try:
        wait = WebDriverWait(driver, 10)
        
        # Fill in job title
        what_field = wait.until(EC.presence_of_element_located((By.ID, "keywords")))
        what_field.clear()
        what_field.send_keys(filters['job_title'])
        
        # Fill in location
        where_field = driver.find_element(By.ID, "location")
        where_field.clear()
        where_field.send_keys(filters['location'])
        
        # Click Find Jobs button
        find_jobs_button = wait.until(EC.element_to_be_clickable((By.ID, "hp-search-btn")))
        highlight_element(driver, find_jobs_button)
        find_jobs_button.click()
        time.sleep(3)  # Wait for results to load

    except Exception as e:
        print(f"Error during job search: {e}")

def highlight_element(driver, element):
    """Highlight an element before clicking it."""
    try:
        actions = ActionChains(driver)
        actions.move_to_element(element)
        actions.perform()
        time.sleep(0.5)
        driver.execute_script("arguments[0].style.backgroundColor = 'yellow'", element)
        time.sleep(0.5)
        driver.execute_script("arguments[0].style.backgroundColor = ''", element)
    except:
        pass

def apply_to_job(driver, job_id, sid):
    """Apply to a job using 1-click apply."""
    try:
        apply_button = driver.find_element(By.ID, f"1clicklink-{job_id}")
        highlight_element(driver, apply_button)
        apply_button.click()
        time.sleep(2)
        return True
    except Exception as e:
        print(f"Error finding apply button: {e}")
        return False

def close_popups(driver):
    """Close any pop-ups that might appear."""
    try:
        popup_selectors = [
            "[class*='popup-close']",
            "[class*='close-button']",
            "[class*='modal-close']",
            "[aria-label='Close']"
        ]

        for selector in popup_selectors:
            try:
                close_buttons = driver.find_elements(By.CSS_SELECTOR, selector)
                for button in close_buttons:
                    if button.is_displayed():
                        highlight_element(driver, button)
                        button.click()
                        time.sleep(0.5)
            except:
                continue

    except Exception as e:
        print(f"Error handling popups: {e}")

def main():
    """Launch an undetected Chrome session and automate job applications."""
    try:
        filters = read_job_filters()
        
        options = uc.ChromeOptions()
        options.add_argument("--start-maximized")
        options.add_argument("--disable-blink-features=AutomationControlled")
        
        driver = uc.Chrome(options=options, version_main=136)
        wait = WebDriverWait(driver, 10)
        
        # Open CV Library
        driver.get("https://www.cv-library.co.uk/")
        time.sleep(2)
        
        input("Press Enter after logging in to continue...")
        print("Login detected. Proceeding with job search...")
        
        search_jobs(driver, filters)
        
        jobs_applied = 0
        while True:
            try:
                time.sleep(2)
                # Find all 1-click apply buttons
                apply_buttons = driver.find_elements(By.CSS_SELECTOR, "a[id^='1clicklink-']")
                
                for button in apply_buttons:
                    try:
                        job_id = button.get_attribute("data-job-id")
                        sid = button.get_attribute("href").split("sid=")[1]
                        
                        close_popups(driver)
                        
                        if apply_to_job(driver, job_id, sid):
                            jobs_applied += 1
                            print(f"Successfully applied! Total applications: {jobs_applied}")
                        
                        time.sleep(1)
                    except Exception as e:
                        print(f"Error processing job: {e}")
                        continue
                
                try:
                    # Updated selector for the next page button
                    next_button = wait.until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, "a.pagination__next"))
                    )
                    if not next_button.is_enabled():
                        print("Reached last page")
                        break
                    highlight_element(driver, next_button)
                    next_button.click()
                    time.sleep(3)
                except NoSuchElementException:
                    print("No more pages")
                    break
                except Exception as e:
                    print(f"Error navigating to next page: {e}")
                    break
                    
            except Exception as e:
                print(f"Error processing page: {e}")
                break
        
        print(f"\nApplication process completed. Applied to {jobs_applied} jobs.")
        input("Press Enter to close the browser...")
        
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    main()
